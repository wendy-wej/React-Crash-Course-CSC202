import React from 'react';
const Welcomer: React.FC = () => {
    return (
        <div>
            <h1>Welcome to SIMS </h1> 
            <p> This is a database system that allows you to input data and output data.</p>
            <p> The middle panel allows you to Enter values into the database.</p>
            <p> The Right panel allows you to view student records.</p>
        </div>
    )
}
export default Welcomer;